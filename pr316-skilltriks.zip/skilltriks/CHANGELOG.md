# Changelog

All notable changes to this project will be documented in this file.

## [1.2] – 2025-09-09 (Feature Release)
### Added
- Notification module including admin and in-app notifications

## [1.1] – 2025-07-08 (Feature Release)
### Added
- User Role Modules
- Assign Course
- Email Notification

## [1.0] – 2025-07-07 (Initial Release)
### Added
- Initial release of the Skilltriks plugin, introducing LMS functionality for WordPress.
