<?php
/**
 * The file that manage the import lesson.
 *
 * @link       https://www.skilltriks.com/
 * @since      1.0.0
 *
 * @package    ST\Lms
 */

namespace ST\Lms\Import;

use function ST\Lms\explode_import_data as explodeData;

/**
 * Import lesson class
 */
class LessonImport extends \ST\Lms\Helpers\FileImport {

	/**
	 * Class construct.
	 */
	public function __construct() {
		$this->import_type  = 2;
		$this->taxonomy_tag = \ST\Lms\STLMS_LESSON_TAXONOMY_TAG;
		$this->init();
	}

	/**
	 * Import file header.
	 *
	 * @return array
	 */
	public function file_header() {
		return array( 'title', 'media_type', 'media_url', 'duration' );
	}

	/**
	 * Import lesson data.
	 *
	 * @param array $value import file data.
	 *
	 * @return int
	 */
	public function insert_import_data( $value ) {
		$lesson_media      = array();
		$lesson_setting    = array();
		$lesson_media_type = array( 'file', 'text', 'video' );

		$lesson = array(
			'post_title'  => $value[0],
			'post_status' => 'publish',
			'post_type'   => \ST\Lms\STLMS_LESSON_CPT,
			'post_author' => 1,
		);

		if ( ! empty( $value[1] ) && in_array( $value[1], $lesson_media_type, true ) ) {
			$media_type   = $value[1];
			$media_url    = ! empty( $value[2] ) ? sanitize_url( $value[2] ) : '';
			$text         = ! empty( $value[3] ) ? wp_kses_post( $value[3] ) : '';
			$lesson_media = array(
				'media_type'      => $media_type,
				'video_id'        => 0,
				'file_id'         => 0,
				'file_url'        => 'file' === $media_type ? $media_url : '',
				'embed_video_url' => 'video' === $media_type ? $media_url : '',
				'text'            => 'text' === $media_type ? $text : '',
			);
		}

		if ( ! empty( $value[6] ) ) {
			$duration_type  = ! empty( $value[7] ) ? rtrim( $value[7], 's' ) : 'minute';
			$lesson_setting = array(
				'duration'      => $value[6],
				'duration_type' => $duration_type,
			);
		}

		$material_title = ! empty( $value[8] ) ? explodeData( $value[8] ) : array();
		$material_url   = ! empty( $value[9] ) ? explodeData( $value[9] ) : array();

		$material = array();

		foreach ( $material_title as $key => $title ) {
			$material[ $key ]['title']        = $title;
			$material[ $key ]['method']       = 'external';
			$material[ $key ]['external_url'] = isset( $material_url[ $key ] ) ? $material_url[ $key ] : '';
		}

		$lesson['meta_input'][ \ST\Lms\META_KEY_LESSON_MEDIA ]    = $lesson_media;
		$lesson['meta_input'][ \ST\Lms\META_KEY_LESSON_SETTINGS ] = $lesson_setting;
		$lesson['meta_input'][ \ST\Lms\META_KEY_LESSON_MATERIAL ] = $material;

		// create lesson.
		$lesson_id = wp_insert_post( $lesson );

		$courses = ! empty( $value[5] ) ? explode( '|', $value[5] ) : array();
		$courses = array_map( 'trim', $courses );

		foreach ( $courses as $course ) {
			if ( is_numeric( $course ) ) {
				$course_id = get_post( (int) $course ) ? (int) $course : 0;
			} else {
				$course_id   = 0;
				$course_data = get_posts(
					array(
						'title'       => $course,
						'post_type'   => \ST\Lms\STLMS_COURSE_CPT,
						'numberposts' => 1,
						'fields'      => 'ids',
					)
				);
				if ( ! empty( $course_data ) ) {
					$course_id = reset( $course_data );
				}

				$create_course = apply_filters( 'stlms_create_new_course', true );
				if ( ! $course_id && $create_course ) {
					$new_course = array(
						'post_title'  => $course,
						'post_status' => 'publish',
						'post_type'   => \ST\Lms\STLMS_COURSE_CPT,
					);

					// create course.
					$course_id = wp_insert_post( $new_course );
				}
			}

			if ( $course_id ) {
				$curriculums = get_post_meta( $course_id, \ST\Lms\META_KEY_COURSE_CURRICULUM, true );
				$curriculums = ! empty( $curriculums ) ? $curriculums : array(
					array(
						'section_name' => '',
						'section_desc' => '',
						'items'        => array(),
					),
				);
				$last_index  = array_key_last( $curriculums );
				if ( isset( $curriculums[ $last_index ]['items'] ) && ! in_array( $lesson_id, $curriculums[ $last_index ]['items'], true ) ) {
					$curriculums[ $last_index ]['items'][] = $lesson_id;
				}
				update_post_meta( $course_id, \ST\Lms\META_KEY_COURSE_CURRICULUM, $curriculums );
			}
		}

		return $lesson_id;
	}
}
